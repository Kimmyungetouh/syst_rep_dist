#include <stdio.h>

int main()
{
    printf("Je fais rien de spécial...😁️\n");
    return 0;
}
